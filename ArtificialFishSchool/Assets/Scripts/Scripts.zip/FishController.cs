﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FishController : MonoBehaviour
{
    private FishState fishstate;

    private float neighbordistance;
    private float crowddistance;

    // Use this for initialization
    void Start ()
    {
        fishstate = GetComponent<FishState>();
        fishstate.Initialize();
        neighbordistance = TankManager.Instance.GetNeighborDistance();
        crowddistance = TankManager.Instance.GetCrowdDistance();
    }
	
	// Update is called once per frame
	void Update ()
    {
        Flocking();
        Containment();
        //Seek(TankManager.Instance.FoodClone.transform.position, fishstate.Starvation);
        fishstate.UpdatePhysicsState();
    }

    private void Flocking()
    {
        List<GameObject> neighbors = TankManager.Instance.GetFishList();

        Vector3 averageposition = Vector3.zero, averagevelocity = Vector3.zero, leave = Vector3.zero;
        float separationcounter = 0, cohesioncounter = 0;
        foreach (GameObject f in neighbors)
        {
            if (f != gameObject)
            {
                float distance = Vector3.Distance(f.GetComponent<FishState>().Position, fishstate.Position);
                if (distance < crowddistance)
                {
                    Vector3 repulsiveforce = fishstate.Position - f.GetComponent<FishState>().Position;
                    repulsiveforce = repulsiveforce.normalized / distance;
                    leave += repulsiveforce;
                    separationcounter++;
                }
                if (distance < neighbordistance && f.GetComponent<FishState>().tag == fishstate.tag)
                {
                    averageposition += f.GetComponent<FishState>().Position;
                    averagevelocity += f.GetComponent<FishState>().Velocity;
                    cohesioncounter++;
                }
            }
        }

        if(cohesioncounter > 0)
        {
            averageposition /= cohesioncounter;
            averagevelocity /= cohesioncounter;
            ApplySteeringForce(averagevelocity);
            Seek(averageposition);
        }
        if (separationcounter > 0)
        {
            leave /= separationcounter;
            ApplySteeringForce(leave);
        } 
    }

    private void Containment()
    {
        Collider[] hitColliders = Physics.OverlapSphere(fishstate.Position, 1.5f, LayerMask.GetMask("Wall"));
        foreach (Collider c in hitColliders)
        {
            Vector3 normalvector = c.gameObject.transform.rotation * Vector3.up;
            float distance = Mathf.Abs(Vector3.Dot(fishstate.Position - c.gameObject.transform.position, normalvector));
            Seek(fishstate.Position + normalvector * 3f / distance);
        }
    }

    private void Seek(Vector3 target, float speedration = 1f)
    {
        ApplySteeringForce(target - fishstate.Position, speedration);
    }

    private void Flee(Vector3 target, float speedration = 1f)
    {
        ApplySteeringForce(fishstate.Position - target, speedration);
    }

    private void ApplySteeringForce(Vector3 desiredvelocity, float speedratio = 1f)
    {
        desiredvelocity.Normalize();
        desiredvelocity *= fishstate.MaxSpeed * speedratio;
        Vector3 steering = desiredvelocity - fishstate.Velocity;
        fishstate.AddForce(steering);
    }

}
