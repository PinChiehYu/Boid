﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FishState : MonoBehaviour{

    public float Mass { get; private set; }
    public Vector3 Position { get; private set; }
    public Vector3 Velocity { get; private set; }
    public float MaxForce { get; private set; }
    public float MaxSpeed { get; private set; }
    public Quaternion Orientation { get; private set; }
    public float Starvation;
    public int tag;

    List<BehaviorType> BehaviorList;
    Dictionary<BehaviorType, Task> TaskList;

    private Vector3 currentforce;

    public void Initialize()
    {
        float tanksize = TankManager.Instance.GetTankSize();
        Mass = Random.Range(1f, 3f);
        Position = new Vector3(Random.Range(-1 * tanksize, tanksize), Random.Range(-1 * tanksize, tanksize), Random.Range(-1 * tanksize, tanksize));
        Velocity = new Vector3(Random.Range(-3f, 3f), Random.Range(-3f, 3f), Random.Range(-3f, 3f));
        MaxForce = Random.Range(20f, 50f);
        MaxSpeed = Random.Range(3f, 9f);
        Orientation = transform.rotation;

        currentforce = Vector3.zero;
        Starvation = Random.Range(0f, 1f);

        UpdatePhysicsState();
    }

    public void UpdatePhysicsState()
    {
        Velocity += currentforce / Mass * Time.deltaTime;
        Velocity = Vector3.ClampMagnitude(Velocity, MaxSpeed);
        Position += Velocity * Time.deltaTime;
        transform.position = Position;
        transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(Velocity) * Orientation, MaxSpeed * Time.deltaTime);

        currentforce = Vector3.zero;

        Starvation -= Time.deltaTime * 0.01f;
        if (Starvation < 0) Starvation = 1f;

        Debug.DrawLine(Position, Position + Velocity);
        float tanksize = TankManager.Instance.GetTankSize();
    }

    public void AddForce(Vector3 force)
    {
        currentforce += Vector3.ClampMagnitude(force, MaxForce);
    }

}
