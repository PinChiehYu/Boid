﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fish {

    private GameObject fishPrefab;
    private FishState fishState;
    private int fishGroupID;
    private List<BehaviorType> fishBehaviorList;
    private FishController fishController;

    public Fish(GameObject prefab, List<BehaviorType> behaviorlist, int groupid)
    {
        fishPrefab = prefab;
        fishBehaviorList = behaviorlist;
        fishGroupID = groupid;

        fishState.Initialize();
    }

    public Fish(FishSetting fishsetting)
    {
        fishPrefab = fishsetting.FishPrefab;
        fishBehaviorList = fishsetting.FishBehaviorList;
        fishGroupID = fishsetting.FishGroupID;

        fishState.Initialize();
    }

    public FishState GetFishState()
    {
        return fishState;
    }

    public int GetFishGroupID()
    {
        return fishGroupID;
    }

    public void UpdateFishState()
    {

    }
}
