﻿using System.Collections;
using System;
using System.Collections.Generic;
using UnityEngine;

public static class BehaviorFactory {

    public static Func<FishState, Vector3, List<Fish>, Vector3> GetBehavior(BehaviorType behavior)
    {
        switch (behavior)
        {
            case BehaviorType.Seek:
                return Seek;
            case BehaviorType.Flee:
                return Flee;
            case BehaviorType.Pursuit:
                return Pursuit;
            case BehaviorType.Evasion:
                return Evasion;
            case BehaviorType.Arrival:
                return Arrival;
            case BehaviorType.Separation:
                return Separation;
            case BehaviorType.Cohesion:
                return Separation;
            case BehaviorType.Alignment:
                return Separation;
            case BehaviorType.Containment:
                
                return Separation;
            default:
                return Seek;
        }
    }

    private static Vector3 Seek(FishState fishstate, Vector3 targetposition, List<Fish> fishlist)
    {
        return targetposition - fishstate.Position;
    }

    private static Vector3 Flee(FishState fishstate, Vector3 targetposition, List<Fish> fishlist)
    {
        return fishstate.Position - targetposition;
    }

    private static Vector3 Pursuit(FishState fishstate, Vector3 targetposition, List<Fish> fishlist)
    {
        return fishstate.Position - targetposition;
    }

    private static Vector3 Evasion(FishState fishstate, Vector3 targetposition, List<Fish> fishlist)
    {
        return fishstate.Position - targetposition;
    }

    private static Vector3 Arrival(FishState fishstate, Vector3 targetposition, List<Fish> fishlist)
    {
        return fishstate.Position - targetposition;
    }

    private static Vector3 Separation(FishState fishstate, Vector3 targetposition, List<Fish> fishlist)
    {
        int counter = 0;
        Vector3 leaveforce = Vector3.zero;
        foreach (Fish f in fishlist)
        {
            //if (f != gameObject)
            //{
                float distance = Vector3.Distance(f.GetFishState().Position, fishstate.Position);
                if (distance < TankManager.Instance.GetCrowdDistance())
                {
                    Vector3 repulsiveforce = fishstate.Position - f.GetFishState().Position;
                    repulsiveforce = repulsiveforce.normalized / distance;
                    leaveforce += repulsiveforce;
                    counter++;
                }
            //}
        }
        if (counter > 0)
        {
            leaveforce /= counter;
        }

        return ConstrainSteeringForce(fishstate, leaveforce);
    }

    private static Vector3 Cohesion(FishState fishstate, Vector3 targetposition, List<Fish> fishlist)
    {
        int counter = 0;
        Vector3 averageposition = Vector3.zero;
        foreach (Fish f in fishlist)
        {
            //if (f != gameObject)
            //{
            float distance = Vector3.Distance(f.GetFishState().Position, fishstate.Position);
            if (distance < TankManager.Instance.GetNeighborDistance())
            {
                averageposition += f.GetFishState().Position;
                counter++;
            }
            //}
        }

        if (counter > 0)
        {
            averageposition /= counter;
        }

        return averageposition - fishstate.Position;
    }

    private static Vector3 Alignment(FishState fishstate, Vector3 target, List<Fish> fishlist)
    {
        int counter = 0;
        Vector3 averagevelocity = Vector3.zero;
        foreach (Fish f in fishlist)
        {
            //if (f != gameObject)
            //{
            float distance = Vector3.Distance(f.GetFishState().Position, fishstate.Position);
            if (distance < TankManager.Instance.GetNeighborDistance())
            {
                averagevelocity += f.GetFishState().Velocity;
                counter++;
            }
            //}
        }

        if (counter > 0)
        {
            averagevelocity /= counter;
        }

        return ConstrainSteeringForce(fishstate, averagevelocity);
    }

    private static Vector3 Containment(FishState fishstate, Vector3 target, List<Fish> fishlist)
    {
        Vector3 resistposition = Vector3.zero;
        Collider[] hitColliders = Physics.OverlapSphere(fishstate.Position, 1.5f, LayerMask.GetMask("Wall"));
        foreach (Collider c in hitColliders)
        {
            Vector3 normalvector = c.gameObject.transform.rotation * Vector3.up;
            float distance = Mathf.Abs(Vector3.Dot(fishstate.Position - c.gameObject.transform.position, normalvector));
            resistposition += fishstate.Position + normalvector * 3f / distance;
        }
        return resistposition - fishstate.Position;
    }

    private static Vector3 ConstrainSteeringForce(FishState fishstate, Vector3 desiredvelocity)
    {
        desiredvelocity.Normalize();
        desiredvelocity *= fishstate.MaxSpeed;
        return desiredvelocity - fishstate.Velocity;
    }
}
