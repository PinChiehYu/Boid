﻿public enum BehaviorType : int
{
    Seek,
    Flee,
    Pursuit,
    Evasion,
    Arrival,
    Separation,
    Cohesion,
    Alignment,
    Containment,
    ObstacleAvoidance,
    Wander,
    Idle
}
