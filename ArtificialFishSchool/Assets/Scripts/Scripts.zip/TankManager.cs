﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TankManager : MonoBehaviour {

    // Use this for initialization
    public static TankManager Instance { get; private set; }

    [SerializeField]
    private GameObject FishClone_1;
    [SerializeField]
    private GameObject FishClone_2;
    [SerializeField]
    public GameObject FoodClone;
    [SerializeField]
    private GameObject WallClone;
    [SerializeField]
    private float SchoolSize;
    [SerializeField]
    private float TankSize;

    [SerializeField]
    private List<FishSetting> FishTypeList;

    private List<GameObject> FishList;
    private List<Fish> fishList;
    private List<GameObject> FoodList;

    [SerializeField]
    private float NeighborDistance;
    [SerializeField]
    private float CrowdDistance;


    void Awake ()
    {
        if (Instance == null)
        {
            Instance = this;
            GameObject.DontDestroyOnLoad(gameObject);

            InitializeTank();
        }
    }

    private void InitializeTank()
    {
        Instantiate(WallClone, new Vector3(TankSize, 0, 0), Quaternion.Euler(90f, 0f, 90f));
        Instantiate(WallClone, new Vector3(-1 * TankSize, 0, 0), Quaternion.Euler(-90f, 0f, -90f));

        Instantiate(WallClone, new Vector3(0, TankSize, 0), Quaternion.Euler(0f, 0f, 180f));
        Instantiate(WallClone, new Vector3(0, -1 * TankSize, 0), Quaternion.Euler(0f, 0f, 0f));

        Instantiate(WallClone, new Vector3(0, 0, TankSize), Quaternion.Euler(-90f, 0, 0f));
        Instantiate(WallClone, new Vector3(0, 0, -1 * TankSize), Quaternion.Euler(90f, 0, 0f));

        FishList = new List<GameObject>();
        FoodList = new List<GameObject>();

        for (int i = 0; i < SchoolSize; i++)
        {
            CreateAndAddFish(FishClone_1, 0);
        }
        for (int i = 0; i < SchoolSize; i++)
        {
            CreateAndAddFish(FishClone_2, 1);
        }
    }

    public void Update()
    {

    }

    private void CreateAndAddFish(GameObject fishclone, int tag)
    {
        fishclone.GetComponent<FishState>().tag = tag;
        FishList.Add(Instantiate(fishclone));
    }

    public float GetTankSize()
    {
        return TankSize;
    }

    public List<GameObject> GetFishList()
    {
        return FishList;
    }

    public List<GameObject> GetFoodList()
    {
        return FoodList;
    }

    public float GetNeighborDistance()
    {
        return NeighborDistance;
    }

    public float GetCrowdDistance()
    {
        return CrowdDistance;
    }
}
