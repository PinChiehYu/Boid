﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FishFactory {

    private Dictionary<string, FishSetting> FishSettingDictionary;

    public GameObject CreateFish(string fishsettingname)
    {

        return new GameObject();
    }
}
