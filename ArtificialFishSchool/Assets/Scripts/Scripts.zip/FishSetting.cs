﻿using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu]
public class FishSetting : ScriptableObject {

    public GameObject FishPrefab;
    public List<BehaviorType> FishBehaviorList;
    public int FishGroupID;

}
