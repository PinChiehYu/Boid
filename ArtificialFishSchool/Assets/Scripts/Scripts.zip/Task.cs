﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;

public class Task
{
    private BehaviorType behaviorType;
    private Vector3 targetPosition;
    Func<FishState, Vector3, List<Fish>, Vector3> behaviorDelegate;

    public Task(BehaviorType behavior, Vector3 position, Func<FishState, Vector3, List<Fish>, Vector3> dele)
    {
        behaviorType = behavior;
        targetPosition = position;
        behaviorDelegate = dele;
    }

    public Vector3 CallTask(FishState fishstate, List<Fish> fishlist, out bool stop)
    {
        stop = false;
        return behaviorDelegate(fishstate, targetPosition, fishlist);
    }

    /*
    private Vector3 ApplySteeringForce(Vector3 desiredvelocity, float speedratio = 1f)
    {
        desiredvelocity.Normalize();
        desiredvelocity *= fishstate.MaxSpeed * speedratio;
        Vector3 steering = desiredvelocity - fishstate.Velocity;
        return steering;
    }
    */
}

    